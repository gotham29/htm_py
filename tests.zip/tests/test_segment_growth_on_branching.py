# tests/test_tm_high_order_branching.py
import unittest
from htm_py.temporal_memory import TemporalMemory

class TestBranchingSegments(unittest.TestCase):

    def setUp(self):
        self.tm = TemporalMemory(
            columnDimensions=(4,),
            cellsPerColumn=4,
            activationThreshold=1,
            initialPermanence=0.3,
            connectedPermanence=0.2,
            minThreshold=1,
            maxNewSynapseCount=4,
            permanenceIncrement=0.1,
            permanenceDecrement=0.0,
            predictedSegmentDecrement=0.0
        )
        self.cols = {
            "A": 0,
            "X": 1,
            "B": 2,
            "C": 3
        }

    def feed_sequence(self, labels):
        for label in labels:
            self.tm.compute([self.cols[label]], learn=True)

    def test_segment_growth_on_branching(self):
        # Feed two different high-order contexts leading to B then C
        self.feed_sequence(["A", "B", "C"])  # context 1
        self.tm.reset()
        self.feed_sequence(["X", "B", "C"])  # context 2

        # Retrieve all cells for column "C"
        col_idx = self.cols["C"]
        c_cells = [col_idx * self.tm.cellsPerColumn + i for i in range(self.tm.cellsPerColumn)]

        # Count number of segments across C cells
        segment_count = sum(self.tm.connections.numSegments(cell) for cell in c_cells)

        print(f"[TEST] Segments on 'C' column cells: {segment_count}")
        self.assertGreaterEqual(segment_count, 2, "Expected at least 2 segments for branching memory on 'C'")

if __name__ == "__main__":
    unittest.main()

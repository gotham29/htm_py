# tests/test_tm_high_order_sequence.py

import unittest
from htm_py.temporal_memory import TemporalMemory

class TestHighOrderSequence(unittest.TestCase):

    def setUp(self):
        self.tm = TemporalMemory(
            columnDimensions=(5,),
            cellsPerColumn=4,
            activationThreshold=1,
            initialPermanence=0.3,
            connectedPermanence=0.2,
            minThreshold=1,
            maxNewSynapseCount=4,
            permanenceIncrement=0.1,
            permanenceDecrement=0.0,
            predictedSegmentDecrement=0.0
        )

    def _run_sequence(self, sequence, learn=True):
        for col in sequence:
            self.tm.compute([col], learn=learn)

    def test_high_order_branching_sequence(self):
        # Train sequence A → B → C
        self._run_sequence([0, 1, 2])
        self.tm.reset()

        # Train sequence A → D → E
        self._run_sequence([0, 3, 4])
        self.tm.reset()

        # Re-run A → B, then check if C is predicted
        self._run_sequence([0, 1], learn=False)
        pred_cells_after_B = self.tm.predictiveCells

        # Reset and run A → D, then check if E is predicted
        self.tm.reset()
        self._run_sequence([0, 3], learn=False)
        pred_cells_after_D = self.tm.predictiveCells

        # Determine expected prediction columns
        pred_cols_B = set(cell // self.tm.cellsPerColumn for cell in pred_cells_after_B)
        pred_cols_D = set(cell // self.tm.cellsPerColumn for cell in pred_cells_after_D)

        self.assertIn(2, pred_cols_B, "Expected C to be predicted after A→B")
        self.assertNotIn(4, pred_cols_B, "E should NOT be predicted after A→B")

        self.assertIn(4, pred_cols_D, "Expected E to be predicted after A→D")
        self.assertNotIn(2, pred_cols_D, "C should NOT be predicted after A→D")

if __name__ == '__main__':
    unittest.main()
